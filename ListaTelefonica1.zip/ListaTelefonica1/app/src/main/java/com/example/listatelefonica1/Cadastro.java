package com.example.listatelefonica1;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

public class Cadastro extends AppCompatActivity {

    private EditText emailField;
    private EditText senhaField;
    private Button cadastrarButton;
    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        emailField = findViewById(R.id.editTextText2);
        senhaField = findViewById(R.id.editTextTextPassword2);
        cadastrarButton = findViewById(R.id.button3);
        auth = FirebaseAuth.getInstance();

        cadastrarButton.setOnClickListener(v -> {
            String email = emailField.getText().toString().trim();
            String senha = senhaField.getText().toString().trim();

            if (email.isEmpty() || senha.isEmpty()) {
                Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
            } else {
                auth.createUserWithEmailAndPassword(email, senha)
                        .addOnCompleteListener(task -> {
                            if (task.isSuccessful()) {
                                Toast.makeText(this, "Cadastro realizado com sucesso!", Toast.LENGTH_SHORT).show();
                                finish();
                            } else {
                                String erro = task.getException() != null ? task.getException().getMessage() : "Erro desconhecido";
                                Toast.makeText(this, "Erro ao cadastrar: " + erro, Toast.LENGTH_LONG).show();
                            }
                        });
            }
        });
    }
}
