package com.example.listatelefonica1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class ContactAdapter extends BaseAdapter {

    Context context;
    ArrayList<Contact> contacts;
    LayoutInflater inflater;

    public ContactAdapter(Context context, ArrayList<Contact> contacts) {
        this.context = context;
        this.contacts = contacts;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return contacts.size();
    }

    @Override
    public Object getItem(int i) {
        return contacts.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    static class ViewHolder {
        TextView name, phone;
        Button callButton;
    }

    @Override
    public View getView(int i, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_contact, null);
            holder = new ViewHolder();
            holder.name = convertView.findViewById(R.id.contactName);
            holder.phone = convertView.findViewById(R.id.contactPhone);
            holder.callButton = convertView.findViewById(R.id.callButton);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        final Contact contact = contacts.get(i);
        holder.name.setText(contact.getName());
        holder.phone.setText(contact.getPhone());

        holder.callButton.setOnClickListener(v -> {
            if (context instanceof MainActivity) {
                ((MainActivity) context).makeCall(contact.getPhone());
            }
        });

        return convertView;
    }
}
